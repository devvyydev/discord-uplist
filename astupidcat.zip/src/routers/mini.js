const app = require('express').Router();
const botsdata = require("../database/models/botlist/bots.js");

console.log("[uplist]: Mini pages router loaded.");

app.get("/error", async (req,res) => {
    res.render("error.ejs", {
    	bot: global.Client,
        path: req.path,
        config: global.config,
        user: req.isAuthenticated() ? req.user : null,
        req: req,
        roles:global.config.server.roles,
        channels: global.config.server.channels
    })
})

app.get("/bot-rules", async (req,res) => {
    res.render("botlist/bot-rules.ejs", {
        bot: global.Client,
        path: req.path,
        config: global.config,
        user: req.isAuthenticated() ? req.user : null,
        req: req,
        roles:global.config.server.roles,
        channels: global.config.server.channels
    })
})

//more pages
app.get("/contact", async (req,res) => {
    res.render("./contact.ejs", {
        bot: global.Client,
        path: req.path,
        config: global.config,
        user: req.isAuthenticated() ? req.user : null,
        req: req,
        roles:global.config.server.roles,
        channels: global.config.server.channels
    })
})
app.get("/credits", async (req,res) => {
    res.render("./credits.ejs", {
        bot: global.Client,
        path: req.path,
        config: global.config,
        user: req.isAuthenticated() ? req.user : null,
        req: req,
        roles:global.config.server.roles,
        channels: global.config.server.channels
    })
})
app.get("/faq", async (req,res) => {
    res.render("./faq.ejs", {
        bot: global.Client,
        path: req.path,
        config: global.config,
        user: req.isAuthenticated() ? req.user : null,
        req: req,
        roles:global.config.server.roles,
        channels: global.config.server.channels
    })
})

//redirects
app.get("/dc", async (req,res) => {
    res.redirect(global.config.server.invite)
})
app.get("/disc", async (req,res) => {
    res.redirect(global.config.server.invite)
})
app.get("/discord", async (req,res) => {
    res.redirect(global.config.server.invite)
})
app.get("/insta", async (req,res) => {
    res.redirect("https://www.instagram.com/discord_uplist")
})
app.get("/instagram", async (req,res) => {
    res.redirect("https://www.instagram.com/discord_uplist")
})
app.get("/yt", async (req,res) => {
    res.redirect("https://youtube.com/channel/UCEI-TcKI6D3h5My6I-am5Gw")
})
app.get("/youtube", async (req,res) => {
    res.redirect("https://youtube.com/channel/UCEI-TcKI6D3h5My6I-am5Gw")
})
app.get("/twitter", async (req,res) => {
    res.redirect("https://twitter.com/mytjic_dev")
})
app.get("/git", async (req,res) => {
    res.redirect("")
})
app.get("/github", async (req,res) => {
    res.redirect("")
})
app.get("/pat", async (req,res) => {
    res.redirect("")
})
app.get("/patteon", async (req,res) => {
    res.redirect("")
})
app.get("/docs", async (req,res) => {
    res.redirect("https://devvyydev.gitbook.io/uplist/")
})

app.get("/robots.txt", function(req, res) {
    res.set('Content-Type', 'text/plain');
    res.send(`Sitemap: https://uplist.devvyy.repl.co/sitemap.xml`);
});

app.get("/sitemap.xml", async function(req, res) {
    let link = "<url><loc>https://uplist.devvyy.repl.co/</loc></url>";
    let botdataforxml = await botsdata.find()
    botdataforxml.forEach(bot => {
        link += "\n<url><loc>https://uplist.devvyy.repl.co/bot/" + bot.botID + "</loc></url>";
    })
    res.set('Content-Type', 'text/xml');
    res.send(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="https://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="https://www.google.com/schemas/sitemap-image/1.1">${link}</urlset>`);
});

module.exports = app;